# Known beta limitations

- Locally verified on Windows 11 x64 build 26200, one AMD GPU/display. Other builds, physical multi-monitor/hybrid GPU/hot-plug and physical DPI transitions remain release gates. The 0.6.3 UI was exercised at native 150% and injected 100/125/150/175/200% DPI layouts; injected messages do not qualify physical transitions.
- At most two unambiguous SDR outputs within existing per-output 4K limits. Clone/spanning, HDR, unsupported color paths and resource failures remain static.
- Native Media Foundation/NV12 hardware decode required, no software/upload fallback. No codec installation; Windows N requires Media Foundation.
- Bounded H.264 Baseline/Main/High, HEVC Main and compatible AV1 profile 0; progressive square-pixel SDR/BT.709, valid timing up to 60 FPS. H.264/HEVC/VFR MP4 were exercised. AV1 capability was detected but no AV1 file played. Other extensions are not a support guarantee.
- Still preview, muted wallpaper; no preview seek/volume or Center framing. Native adjustments depend on the device; tested sharpness is unavailable.
- Rare scheduler-delayed coverage expiry safely makes playback eligible; stale trust is never extended. Windows scheduling is not real-time.
- One actual Windows 11 login of e79dd74 restored motion before the UI opened, confirmed by both presentation timing and the user. The exact final packaged build still needs two actual login confirmations. Modern Standby wake and lock/unlock passed; physical battery/Energy Saver, traditional S3 suspend and extended interaction/accessibility remain unqualified.
- Bounded library/playlists; future entries are not preloaded. Offline optimization requires playback stopped. Efficiency may reduce cadence; Balanced fits the display and High Quality may retain source resolution. Estimates can be wrong and copies larger. Local measurements apply only to the tested source/PC, not every file.
- No Workshop, accounts, web wallpapers, editor or shader scenes.
- Public identity/license/signing/provenance pending. Local candidate is unsigned/unofficial.

- Tray actions were exercised through the real runtime notification callback/commands and Shell icon registration; exhaustive human interaction and third-party game fullscreen combinations remain unqualified.
- A stale portable installation can still exist alongside the per-user install; launch the installed Lite Wallpaper shortcut to use this candidate.
