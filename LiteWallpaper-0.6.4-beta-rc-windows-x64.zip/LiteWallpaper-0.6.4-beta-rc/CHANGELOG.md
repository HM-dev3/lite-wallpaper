# Changelog

## Release preparation — 1.0.0 remains gated

- Preserve active wallpaper intent during upgrades independently of Start with Windows. An intentionally stopped assignment remains stopped.
- Restore reads the active configuration once; startup diagnostics now include config-load entry and completion. Normal runtime logging keeps the warning/error threshold.
- Prepare version-checked tagged packaging, checksums, exact build identity, trusted signing and workflow provenance for the future 1.0.0 release. No public tag/release or attestation has been created.
- One actual Windows 11 login of e79dd74 restored motion before opening the UI. Modern Standby wake and lock/unlock passed on that installed candidate. Exact final-package reboot confirmation remains required.

## 0.6.4 Beta release candidate — final engine pass

- System resume rebuilds playback automatically after an armed suspend release, using native events and preserving independent inhibits. Stop cancels restore intent; duplicate wake notifications do not rebuild an active decoder.
- Relinking a moved original preserves the reversible optimized-copy relationship when cached size/revision evidence matches. A replacement with different identity detaches stale links; relinking also works at library capacity.
- Restore and system suspension have truthful status labels. Final real reboot/logon and physical sleep/wake checks remain pending.
- Supported native video filters and immediate Reset are on Wallpaper below Playback; no separate Adjustments page. Policies remain only in Preferences.
- Interrupted startup topology transactions remain Waiting for desktop and recover from shell/display events. Verified native posters are not redundantly reinstalled.
- Fixed startup phase timestamps expose process, shell, topology, host, device, decoder, first decoded sample and successful Present boundaries.
- Offline preparation accounts for monitor refresh, retains cinematic rational rates and allows High Quality to retain source detail. Ideal sources are not recompressed without a useful expected benefit.
- No new runtime thread, polling loop, decoder or rendering pass. The local original/prepared comparison is documented separately; it is not a universal savings claim.
- Actual final-build reboot/logon verification remains required before a 1.0 release; public identity, license and signing remain unconfigured.

## 0.6.3 Beta release candidate

- Rebuilt native control UI using Direct2D/DirectWrite and cached WIC stills; pure-black shell, fixed footer and independent clipped panes.
- Separated product model, layout, rendering, interaction, IPC and background work.
- Stable logical keyboard order, native slider accessibility names and legacy selection policy recovery.
- Runtime-owned notification icon with Open, Pause/Resume, playlist Next/Previous, Stop & restore and Exit; TaskbarCreated recreation.
- Immediate compatible per-output policy updates retain decoder/host ownership; independent inhibit sources remain independent.
- Installed 0.5 fullscreen Release failure reproduced with actual Chrome video and its no-redirection style; current candidate verified with that real app.
- Public publication remains deferred; unsigned local candidate, owner identity/license decisions pending.

## 0.6.2 Beta candidate

- Final native black UI and approved branding; cached still preview and file information.
- Library/playlists, per-output framing/settings, speed, supported live adjustments and policies.
- Optional runtime-only startup and offline prepared copies preserving originals.
- Guarded media compatibility and two-output adapter-domain architecture.
- Correct fullscreen admission including composition-only foreground windows.
- Immediate policy synchronization and older-runtime replacement on Apply.
- Compiled identity, per-user installer/removal and release integrity pipeline.

Public release awaits owner identity/license decisions. Historical architecture failures and local performance evidence remain in docs and Git history; no universal performance claim is made.
