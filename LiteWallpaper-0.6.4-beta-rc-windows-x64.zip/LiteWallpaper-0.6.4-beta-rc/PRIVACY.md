# Privacy

No accounts, telemetry or automatic uploads. Playback, settings, library metadata, cached stills and diagnostics are local. Explicitly selected network/UNC files may cause Windows network access.

Policies inspect window identities, geometry, visibility and foreground state; they do not capture typed text or screen recordings. Cached stills contain selected video content. Diagnostics may include paths, monitor identifiers and process/window/hardware metadata; review/redact them before sharing.

Support/repository links open configured HTTPS pages only when clicked and are disabled while unset. Offline optimization is an explicit temporary operation. Closing the UI exits it completely; active playback remains until Stop & restore. Uninstall preserves user data. There is no automatic crash-report submission.
