# Security and authentic releases

The local candidate is unsigned. No trusted signing credential is configured; no self-signed certificate substitutes for public identity.

Official assets must come from the tagged GitHub workflow and identify author, repository, version, commit and tag. Verify SHA-256 and provenance against that repository's release workflow/source digest. If a trusted credential is added, every EXE/installer script must have a verified SHA-256 Authenticode signature and RFC3161 SHA-256 timestamp before packaging.

Forks can remove branding. Modified binaries have different digests and cannot verify as the exact official attested artifact. Checksums from an untrusted location do not prove authorship.

## Reporting and credentials

Official repository/private vulnerability reporting are pending owner configuration. Enable GitHub private vulnerability reporting before publication and link it here. No email or response promise is invented. Do not publish secrets or private paths in public issues.

Provision signing keys through a protected release environment/provider, never source. The signing script uses a certificate already in the Windows user store. Public release fails closed if identity or source-license approval is missing.
