# Lite Wallpaper 0.6.4 release candidate

A lightweight native Windows live-wallpaper application focused on performance.

This private, unsigned candidate preserves the hardened native engine and approved UI. It adds an installer correction: upgrading an active wallpaper no longer loses restore intent when Windows startup is disabled. Intentional Stop remains inactive. Startup reads the restore configuration once and records config-load timing; no thread, polling loop, decoder or rendering pass was added.

Library, playlists, speed, supported native colors, behavior policies, tray, guarded per-monitor architecture and optional offline prepared copies remain available. Closing the UI exits it completely.

Extract the full ZIP and launch Install.cmd from Windows File Explorer. No administrator is needed. See INSTALL.md. Upgrade preserves user data and the independent startup preference. Originals are never bundled or deleted.

The preceding hardened candidate restored automatically at one actual Windows 11 login before its UI opened; the user confirmed visible movement. Modern Standby wake and lock/unlock also passed. These are local results, not certification of this new package's two required reboot checks. This artifact is not labeled 1.0.0.

Local Windows 11 build 26200, integrated AMD GPU, one display. Fresh physical Windows 10, weak-PC, multiple-output/hybrid GPU, battery/Energy Saver and HDR/clone support are not qualified. Unsupported native decode/topology uses static fallback where possible. AV1 file playback remains unverified. No universal CPU/GPU/battery savings are claimed.

No trusted signing credential is configured. This candidate is unsigned and has no GitHub provenance attestation. SHA-256 and build metadata establish byte integrity, not publisher authentication. Never disable Windows security globally to install it.

Public publication is blocked pending owner identity/license/repository decisions.
