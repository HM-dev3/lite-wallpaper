param([switch]$NoLaunch)
$ErrorActionPreference='Stop'
Add-Type -TypeDefinition @'
using System.Runtime.InteropServices;
using System;
using System.IO;
using System.Text;
public static class LiteInstallContext {
 [DllImport("kernel32.dll", CharSet=CharSet.Unicode)]
 public static extern int GetCurrentPackageFullName(ref uint length, System.Text.StringBuilder name);
 [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
 static extern IntPtr CreateFile(string path, uint access, uint share, IntPtr security, uint disposition, uint flags, IntPtr template);
 [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
 static extern uint GetFinalPathNameByHandle(IntPtr handle, StringBuilder path, uint length, uint flags);
 [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
 public static void VerifyDirectory(string path) {
  if(!Directory.Exists(path)) return;
  string probe=Path.Combine(path,".lite-install-check-"+Guid.NewGuid().ToString("N"));
  IntPtr handle=CreateFile(probe,0xC0010080,7,IntPtr.Zero,1,0x04000100,IntPtr.Zero);
  if(handle==new IntPtr(-1)) throw new IOException("Cannot verify installation directory");
  var buffer=new StringBuilder(32768);
  try {
   uint size=GetFinalPathNameByHandle(handle,buffer,32768,0);
   if(size==0 || size>=32768) throw new IOException("Cannot resolve installation directory");
   string actual=buffer.ToString();if(actual.StartsWith(@"\\?\")) actual=actual.Substring(4);
   if(!String.Equals(actual,Path.GetFullPath(probe),StringComparison.OrdinalIgnoreCase))
    throw new IOException("Redirected AppData: run Install.cmd from Windows File Explorer");
  } finally {CloseHandle(handle);}
 }
}
'@
[uint32]$packageLength=0
if([LiteInstallContext]::GetCurrentPackageFullName([ref]$packageLength,$null) -ne 15700){
 throw 'Run Install.cmd from Windows File Explorer. This packaged launcher redirects AppData; installing here would create a private copy invisible to Windows login.'
}
$source=$PSScriptRoot
$destination=Join-Path $env:LOCALAPPDATA 'Programs\LiteWallpaper'
[LiteInstallContext]::VerifyDirectory($env:LOCALAPPDATA)
[LiteInstallContext]::VerifyDirectory((Join-Path $env:LOCALAPPDATA 'Programs'))
[LiteInstallContext]::VerifyDirectory($destination)
[LiteInstallContext]::VerifyDirectory((Join-Path $env:LOCALAPPDATA 'LiteWallpaper'))
$manifest=Get-Content -LiteralPath (Join-Path $source 'package.json') -Raw|ConvertFrom-Json
foreach($file in $manifest.files){
 if([IO.Path]::GetFileName($file.name) -ne $file.name){throw 'Invalid package file name'}
 if((Get-FileHash -LiteralPath (Join-Path $source $file.name) -Algorithm SHA256).Hash -ne $file.sha256){throw "Package verification failed: $($file.name)"}
}
if([IO.Path]::GetFullPath($source).TrimEnd('\') -eq [IO.Path]::GetFullPath($destination).TrimEnd('\')){throw 'Run Install.cmd from the extracted download folder'}
$installedUi=Join-Path $destination 'LiteWallpaper.exe'
if(Get-Process LiteWallpaper -ErrorAction SilentlyContinue){throw 'Close the Lite Wallpaper window, then run Install.cmd again'}
$runKey='HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
$startupEnabled=$null -ne (Get-ItemProperty -Path $runKey -Name 'Lite Wallpaper' -ErrorAction SilentlyContinue)
$configFile=Join-Path $env:LOCALAPPDATA 'LiteWallpaper\config.json'
$wasActive=$false
if(Test-Path $configFile){$prior=Get-Content -LiteralPath $configFile -Raw|ConvertFrom-Json;$wasActive=$prior.active -eq $true}
$old=Join-Path $destination 'LiteWallpaper.Runtime.exe'
$owners=@(Get-Process LiteWallpaper.Runtime -ErrorAction SilentlyContinue)
if($owners.Count){
 $client=Start-Process -FilePath (Join-Path $source 'LiteWallpaper.Runtime.exe') -ArgumentList '--restore' -WindowStyle Hidden -PassThru
 if(-not $client.WaitForExit(15000) -or $client.ExitCode -ne 0){throw 'Stop/restore the current wallpaper before updating'}
 foreach($owner in $owners){if(-not $owner.WaitForExit(15000)){throw 'Runtime did not stop; try Stop in the control app'}}
}
New-Item -ItemType Directory -Path $destination -Force|Out-Null
foreach($file in $manifest.files){Copy-Item -LiteralPath (Join-Path $source $file.name) -Destination (Join-Path $destination $file.name) -Force}
foreach($name in @('package.json','Install.ps1','Install.cmd','Uninstall.ps1','Uninstall.cmd','README.txt','build-identity.json')){Copy-Item -LiteralPath (Join-Path $source $name) -Destination (Join-Path $destination $name) -Force}
New-Item -Path 'HKCU:\Software\LiteWallpaper' -Force | Out-Null
Set-ItemProperty -LiteralPath 'HKCU:\Software\LiteWallpaper' -Name 'InstallPath' -Value ([IO.Path]::GetFullPath($destination))
$shell=New-Object -ComObject WScript.Shell
$shortcut=Join-Path ([Environment]::GetFolderPath('Programs')) 'Lite Wallpaper.lnk'
$link=$shell.CreateShortcut($shortcut);$link.TargetPath=$installedUi;$link.WorkingDirectory=$destination;$link.IconLocation=$installedUi+',0';$link.Description='Lite Wallpaper native controls';$link.Save()
Write-Host "Installed Lite Wallpaper in $destination"
if($startupEnabled){New-Item -Path $runKey -Force|Out-Null;$startupCommand='"'+$old+'" --autostart';Set-ItemProperty -Path $runKey -Name 'Lite Wallpaper' -Value $startupCommand
 if((Get-ItemPropertyValue -LiteralPath $runKey -Name 'Lite Wallpaper') -cne $startupCommand){throw 'Installed startup command verification failed'}}
# Playback restore intent and Windows startup preference are independent.
# Stop/restore above is an upgrade operation, not the user's intentional Stop.
if($wasActive -and (Test-Path $configFile)){$saved=Get-Content -LiteralPath $configFile -Raw|ConvertFrom-Json;$saved.active=$true;[IO.File]::WriteAllText($configFile,($saved|ConvertTo-Json -Depth 16 -Compress),[Text.UTF8Encoding]::new($false))}
Write-Host 'Open Lite Wallpaper from Start. Windows startup is optional and OFF by default; no service was added.'
if(-not $NoLaunch){Start-Process -FilePath $installedUi}
