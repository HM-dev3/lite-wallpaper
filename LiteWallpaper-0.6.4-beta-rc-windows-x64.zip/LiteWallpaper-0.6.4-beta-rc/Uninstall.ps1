$ErrorActionPreference='Stop'
$directory=[IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
$expected=[IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'Programs\LiteWallpaper')).TrimEnd('\')
if($directory -ne $expected){throw 'Use Uninstall.cmd from the installed Lite Wallpaper folder'}
if(Get-Process LiteWallpaper -ErrorAction SilentlyContinue|Where-Object {$_.Path -eq (Join-Path $directory 'LiteWallpaper.exe')}){throw 'Close the Lite Wallpaper window before uninstalling'}
$engine=Join-Path $directory 'LiteWallpaper.Runtime.exe'
$owners=@(Get-Process LiteWallpaper.Runtime -ErrorAction SilentlyContinue)
$client=Start-Process -FilePath $engine -ArgumentList '--restore' -WindowStyle Hidden -PassThru
if(-not $client.WaitForExit(15000) -or $client.ExitCode -ne 0){throw 'Stop/restore wallpaper before uninstalling'}
foreach($owner in $owners){if(-not $owner.WaitForExit(15000)){throw 'Runtime still active'}}
$journal=Join-Path $env:LOCALAPPDATA 'LiteWallpaper\static-restore.json'
if((Test-Path $journal) -and @((Get-Content $journal -Raw|ConvertFrom-Json)).Count -ne 0){throw 'Reconnect displays and complete Stop/restore before uninstalling'}
$runKey='HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
$startup=Get-ItemProperty -Path $runKey -Name 'Lite Wallpaper' -ErrorAction SilentlyContinue
if($startup -and $startup.'Lite Wallpaper' -eq ('"'+$engine+'" --autostart')){Remove-ItemProperty -Path $runKey -Name 'Lite Wallpaper'}
$installKey='HKCU:\Software\LiteWallpaper'
$registeredPath=Get-ItemPropertyValue -LiteralPath $installKey -Name 'InstallPath' -ErrorAction SilentlyContinue
if($registeredPath -and [IO.Path]::GetFullPath($registeredPath).TrimEnd('\') -eq $directory){Remove-ItemProperty -LiteralPath $installKey -Name 'InstallPath'}
$manifest=Get-Content -LiteralPath (Join-Path $directory 'package.json') -Raw|ConvertFrom-Json
foreach($file in $manifest.files){
 if([IO.Path]::GetFileName($file.name) -ne $file.name){throw 'Invalid installed file name'}
 $target=Join-Path $directory $file.name
 if((Test-Path -LiteralPath $target) -and (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -eq $file.sha256){Remove-Item -LiteralPath $target}
}
$shortcut=Join-Path ([Environment]::GetFolderPath('Programs')) 'Lite Wallpaper.lnk'
if(Test-Path -LiteralPath $shortcut){
 $shell=New-Object -ComObject WScript.Shell
 if($shell.CreateShortcut($shortcut).TargetPath -eq (Join-Path $directory 'LiteWallpaper.exe')){Remove-Item -LiteralPath $shortcut}
}
Write-Host 'Lite Wallpaper removed. Your videos, saved settings and static poster files were preserved.'
Write-Host 'You can remove the remaining installer/readme files from this folder yourself.'
