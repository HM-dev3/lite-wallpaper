LITE WALLPAPER — native beta 0.6.4-beta-rc

QUICK START
1. Extract the entire ZIP. Run Install.cmd for per-user installation, or run
   LiteWallpaper.exe beside its runtime and DLLs. No admin account is required.
   Launch Install.cmd from Windows File Explorer. Launching from an unrelated
   MSIX-packaged app is rejected to prevent a private install/restore store that
   Windows login cannot see.
2. Add local videos, select a display and Fill/Fit/Stretch, then Apply. Selecting
   an individual display preserves its neighbors. All supported displays applies
   the same selection to all. Each display remembers its own settings.
3. Pause/Resume retains position. Stop & restore ends the runtime and restores
   the previous static backgrounds. Close the UI to leave only the runtime.
4. Wallpaper contains playback speed and framing. Playlists contains rotation.
   Behavior policies exist only in Preferences / Behavior / Performance,
   alongside startup, presets and offline optimization. There is no Adjustments
   page. Supported live visual controls and Reset are below Playback on Wallpaper.

SUPPORTED PLAYBACK / DISPLAY LIMITS
Muted local native H.264 (Baseline/Main/High), HEVC Main and compatible AV1
profile 0, within 3840x2160 pixels (either side <=3840), progressive/sample-
described, square pixels, SDR/BT.709, valid nominal timing up to 60 FPS.
Actual Windows decoder, owning-GPU NV12 decoder support and native GPU decoder
surfaces are required; no software/upload playback fallback. Missing/unsupported
codecs, profiles, HDR/color paths, invalid timestamps or resource limits use a
static poster where available. Only MP4 files were played in local 0.7 checks.
Other containers are attempted through Media Foundation; extensions are not a
support promise. AV1 decoder/GPU capability was detected but no local AV1 file
was available for playback verification. HEVC and VFR MP4 playback were verified.
VFR uses actual ordered PTS and positive sample durations; missing/unordered or
changing-resolution timing fails explicitly.
At most two unambiguous SDR displays on the supported Windows 11 build 26200
backend, within the existing 4K pixel budget per output. HDR, clone/spanning,
ambiguous topology and resource failures remain static. Compatible assets/rates
and suspension policies on one GPU share a decoder/device; framing and visuals
remain output-specific. Different GPUs have independent domains. Physical
multi-monitor and hybrid-GPU qualification remain release gates.

START WITH WINDOWS (DEFAULT OFF)
Use the startup toggle after installing to a stable local path. It adds one
per-user Windows Run entry that launches LiteWallpaper.Runtime.exe --autostart
with no control UI, service or launcher helper. The last active wallpaper and
output assignments restore automatically. Stop marks playback inactive, so the
next login does not restart it; Apply marks it active again. Disable the toggle
to remove the entry. Portable folders must remain at the same location.
Windows may delay startup. One actual login passed on the hardened e79dd74
candidate; the exact new package still requires two real login confirmations.

LIBRARY / PER-DISPLAY SETTINGS
Search, manual/name/recent sorting, favorites-only filtering, Favorite, Pin and
Up/Down operate on metadata and cached stills. The library holds at most 64
original paths and bounded thumbnails; browsing does not decode video. Add is
an explicit import/refresh. Missing or changed sources disable Apply until you
Relink their current location in Preferences. Add refreshes changed/older metadata.
Remove library entry never deletes an original video. Pinned items stay
above unpinned items; Up/Down changes manual order within those groups.
Select a display to edit its own source, framing, speed and behavior.
Apply changes that display. Speed updates live; policy selections in Preferences
apply immediately. Fullscreen policy includes maximized foreground apps.
The global Pause/Resume control applies to every output. Supported visual filters
update the active wallpaper without Apply; Reset immediately returns to neutral.
Unsupported Sharpness is disabled. Neutral filters add no software processing.

PERFORMANCE PRESETS
Maximum Efficiency: covered pause, fullscreen resource release, battery/Energy
Saver pause; prefers an existing prepared 30 FPS copy when available.
Balanced: covered/fullscreen pause, focus keep, reduced activity on battery.
Always Running: fewer automatic suspensions; lock/suspend/display-off/remote
and manual Pause safety gates remain effective. Presets preserve rate and legacy
saved visual values. Individual policies remain customizable in Preferences.
Reduced activity uses the existing half-speed policy.
Physical battery/Energy Saver transitions remain a release gate.

PLAYLISTS
Create a name, add selected library wallpapers, remove/reorder items, rename or
delete the playlist. Choose Shuffle and Loop as desired. Save rotation seconds:
0 means manual only, 10..86400 enables timed rotation. Play on selected display
activates the saved list; Previous/Next navigate it. Playlist edits take effect
on the next navigation or explicit Play. Shuffle establishes one shuffled order
per activation/edit, with reversible Previous; Loop repeats that order.
Rotation waits while paused/covered/inhibited, then starts a fresh interval.
A non-looping list stops rotating at the last item. Missing/changed files stop
rotation with an error; the current wallpaper remains. Only the current item is
opened/decoded; future items are never preloaded. At most 16 lists, 64 items each.
Deleting a running list leaves its current item and stops rotation on the next
navigation/deadline. Playlists reference library paths, not copied video files.

OPTIMIZE FOR LITE WALLPAPER (EXPLICIT / OFFLINE)
Select a source and choose Optimize for Lite Wallpaper to analyze its resolution,
FPS, codec/profile, bitrate, duration and audio against the monitor and qualified
native decode profile. The proposal displays an estimated size before conversion.
Keep an already compatible original; a prepared copy can be larger.
Stop playback before Create optimized copy. Conversion holds the runtime's
instance ownership so playback cannot overlap it. The original remains untouched.
Efficient: fit the source within the selected monitor and a 1920x1080 cap;
retain 24/25/30 and fractional equivalents, halve rates above 30 (50->25,
59.94->29.97, 60->30). Balanced: monitor size, up to 2560x1440 and 60 FPS.
High Quality: monitor size within the existing 4K pixel budget, up to 60 FPS.
All preserve source aspect within even-pixel rounding, never upscale, remove
audio and produce an optional H.264 Main SDR/BT.709 MP4 using Windows Media
Foundation offline. Bitrate depends on size/rate/preset, bounded 1..50 Mbps
and capped to known source bitrate when >=1 Mbps. Review the lossy copy; it may
be larger. Analysis checks selected adapter decoder support, reducing to a
smaller target if needed; no compatible target produces a clear error.
Progress arrives only during conversion; Cancel or closing UI ends the temporary
converter and removes that job's partial copy. No helper remains. Play original /
Play optimized explicitly applies either choice; Optimize on a prepared entry
reanalyzes its original. Remove prepared copy after Stop deletes only a managed
prepared MP4 and retains the original file/entry. Copies are optional/reversible.
Optimizer supports square-pixel progressive/sample-described SDR sources within
the pixel budget, with nominal 1..240 FPS and known duration <=1 hour. It does
not convert HDR, rotated media, variable resolution, or unavailable codecs. No
lossless remux or codec installation. No CPU/GPU/power savings are claimed.

USER DATA

Settings, assignments, library, playlists and prepared copies live under
%LOCALAPPDATA%\LiteWallpaper. Static posters live under Pictures\LiteWallpaper.
Your original files and historical QuietWall evidence are preserved. Stop restores
only static backgrounds still owned by Lite Wallpaper, preserving Windows changes.
Reconnect missing displays and retry Stop when restoration is incomplete. Use a
normal static Windows background; slideshow/Spotlight restoration is unsupported.

UPDATES / UNINSTALL
Close the UI before updating. Run Install.cmd from the new extracted package.
Windows startup stays off unless previously enabled; enabled entries keep pointing
to the installed runtime. Uninstall.cmd in the installed folder stops/restores,
removes its startup entry and unchanged binaries/shortcut, preserving user data.
This unsigned local beta may trigger Windows unrecognized-app warnings. VC runtime
DLLs are bundled. Windows N requires Media Foundation; no codecs are installed.

VALIDATION
Eight regression suites passed once, plus targeted native media, preset,
prepared-file and UI/controller checks.
Closing UI leaves no UI/helper; neutral filters bypass; pause and covered states
quiesce reads/Presents/timer activity. No competitive benchmark or performance
qualification campaign was run. Hardware multi-monitor, battery/Energy Saver,
physical traditional S3 suspend and the exact new package's login confirmations
remain user/release checks. Modern Standby wake and lock/unlock passed on the
hardened installed candidate. This is a guarded daily-use beta.

RETAINED NATIVE UI / 0.6.4
One retained Win32 window uses Direct2D/DirectWrite/WIC. Routine controls are
virtual, with central focus, keyboard input, hit testing and pane clipping.
The original supplied branding asset is preserved. No animation loop, browser,
permanent helper or idle status polling. Live adjustments coalesce at 40 ms;
closing flushes final settings and exits. Unsupported native filters are disabled.
Sharpness is unavailable on the tested AMD device. A rate that splits a shared
producer can require a targeted replacement; compatible rates update in place.
Physical multi-monitor DPI transitions remain unqualified.

POLISH BUILD IDENTITY
0.6.4-beta-rc preserves the completed 0.7 compatibility/optimizer implementation.
The preview is a cached frame, not a second playing decoder. No preview seek,
volume or Center framing controls are provided. The UI paints only on changes.
About shows configure-time build commit and author/repository/support fields.
Unconfigured official links are disabled. Public identity and trusted
Authenticode signing remain release gates until supplied by the developer.
No self-signed production identity or background verification is installed.

The runtime owns the notification icon. Closing the control UI exits it completely. Use the icon to reopen, pause/resume, move an active playlist, Stop & restore, or Exit.

0.6.4 PRODUCT RECOVERY CANDIDATE
The controls share one event-driven Direct2D/DirectWrite window surface. No
ordinary child-window widgets, browser runtime or idle animation are used.
Preview is a cached still; the wallpaper engine is the only playback decoder.
Speed accepts 0.10–4.00, presets and an exact numeric value. Hardware/display
capacity can limit high-rate presentations; overdue frames are dropped.
Playing requires a first presentation from the current host and no active
inhibit. Suspended: power means battery or Windows Energy Saver is active;
Preferences > Power policy controls this deliberately. Apply never bypasses it.
A differently located control/runtime copy is replaced gracefully on launch/
Apply, preventing a portable/test copy from silently owning an installed session.
This is an unsigned local recovery candidate. Publication remains stopped.
