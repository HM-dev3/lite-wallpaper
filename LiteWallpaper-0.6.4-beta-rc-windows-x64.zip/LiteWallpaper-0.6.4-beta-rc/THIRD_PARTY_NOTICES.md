# Packaged dependencies

The Windows beta includes Microsoft Visual C++ 2022 x64 runtime files: msvcp140.dll, vcruntime140.dll and vcruntime140_1.dll, copied from the installed Visual Studio VC143 redistributable directory. These Microsoft components retain their vendor terms and signatures; they are not covered by an as-yet unselected project license.

Windows/Media Foundation/Direct3D are operating-system dependencies, not bundled codecs. Original video wallpapers are not packaged. The approved UI screenshot depicts a user-supplied wallpaper; confirm permission to publish that screenshot before making the repository public.

The project's software license remains an owner decision. This notice does not choose or change it.
