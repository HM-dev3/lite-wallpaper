# Install Lite Wallpaper

## Verify

Use the official GitHub Release once configured. Match its commit/tag, release-metadata.json, SHA256SUMS.txt and workflow attestation. Local unsigned candidates are marked unofficial. Checksums alone do not authenticate a publisher.

```powershell
Get-FileHash .\LiteWallpaper-VERSION-windows-x64.zip -Algorithm SHA256
```

Compare the entire digest with SHA256SUMS.txt. Use the exact provenance verification command in release-metadata.json. If signed, require Valid from Get-AuthenticodeSignature for both EXEs and installer scripts, with the expected official signer.

## Install and use

1. Extract the whole ZIP. Run Install.cmd for per-user installation, or LiteWallpaper.exe for portable use. Keep bundled DLLs beside the EXEs.
   Run it from Windows File Explorer. A launch inside another MSIX app is rejected because its redirected private AppData is invisible to normal Windows login.
2. Add a local supported video, select output/framing, Apply.
3. Configure policies, then close the UI to leave only the runtime.
4. Pause/Resume retains position; Stop & restore returns to static backgrounds.

Replace VERSION with the downloaded filename's exact version. No administrator is required. Unsigned builds may show Windows warnings; verify origin before proceeding and do not disable system-wide security. Missing codecs/hardware may cause static fallback. Startup is optional/off by default; keep portable folder paths stable. The installed startup entry launches the current installed runtime directly with --autostart, never the control UI. It restores only an active assignment, waits for desktop events when needed and keeps truthful status until presentation begins. Stop marks playback inactive for the next login.

## Upgrade and uninstall

Close the UI, then run the new Install.cmd. It stops/restores the old runtime, preserves the prior active state and rewrites enabled startup registration to the installed runtime before replacement finishes. Run Uninstall.cmd from the installed folder to stop/restore and remove its startup entry, shortcut and unchanged binaries. Settings, library, playlists, prepared metadata, restore journal, caches, original videos and unrecognized/modified files are preserved. Portable users should Stop & restore before deleting their folder. User data is in %LOCALAPPDATA%\LiteWallpaper; review it before sharing diagnostics.
